# Employee Salary Data Processing Project

This project contains assignment requirements for processing employee salary data using both Python and R.

Project Files
- `Assignment-Jupyter NB`: Jupyter notebook with data import, processing, error handling, export & zip.
- `R Script 1 & R Script`: R script that unzips the employee profile folder and displays the data.
- `Employee_Profile.zip`: Contains the exported employee CSV.
- `README`: Instructions for using the code.

 Instructions

 Python Steps (Jupyter Notebook):
1. Open `Assignment-Jupyter NB` in Jupyter Notebook.
2. Run all cells in order:
   - Loads salary data.
   - Defines a function to return employee details.
   - Handles missing/invalid names gracefully.
   - Exports selected employee info to CSV and compresses to ZIP.

 R Steps:
1. Open `R Script 1 & R Script` in RStudio.
2. Make sure `Employee_Profile.zip` is in the same directory.
3. Run the R script to unzip and display the CSV data.

