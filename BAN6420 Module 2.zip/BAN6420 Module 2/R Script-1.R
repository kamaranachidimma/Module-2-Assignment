> setwd("C:/Users/JOY NWINYINYA/Downloads")
> unzip("Employee_Profile.zip", exdir = "Employee_Profile")
> setwd("Employee_Profile")
> list.files()
[1] "NATHANIEL_FORD.csv"
> employee_data <- read.csv("NATHANIEL_FORD.csv")
> View(employee_data)
> print(employee_data)